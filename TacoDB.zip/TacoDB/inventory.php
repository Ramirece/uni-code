<?php 
 ?>

<!DOCTYPE hmtl>
<html>

<head>
	<title> Tomas Tacos - CesarRamirez </title>
	<link rel="stylesheet" type="text/css" href="indexStyle.php" />
</head>

<body>
extra &nbsp;&nbsp; space
	<h1>Tomas Tacos </h1>
	<ul class="nav">
		<li><a href="index.php">| TACOS |<a/>
		</li>
		<li><a href="sales.php">| SALES |<a/>
		</li>
		<li><a href="ingredients.php">| INGREDIENTS |<a/>
		</li>
		<li><a href="inventory.php">| INVENTORY |<a/>
		</li>
	</ul> 



<p> INVENTORY</p>
 <br>

</body>

</html>