<?php 
 ?>

<!DOCTYPE hmtl>
<html>

<head>
	<title> Tomas Tacos - CesarRamirez </title>
	<link rel="stylesheet" type="text/css" href="indexStyle.php" />
</head>

<body>
extra &nbsp;&nbsp; space
	<h1>Tomas Tacos </h1>
	<ul class="nav">
		<li><a href="index.php">| TACOS |<a/>
		</li>
		<li><a href="sales.php">| SALES |<a/>
		</li>
		<li><a href="ingredients.php">| INGREDIENTS |<a/>
		</li>
		<li><a href="inventory.php">| INVENTORY |<a/>
		</li>
	</ul> 



<p> FULL INGREDIENT LIST</p>
 <br>


<table align = "center">
<tr>
<th>Name</th>
<th>Price</th>
<th>Preparation</th>
<th>Units of measure (oz)</th>
</tr>

<?php 
$conn = mysqli_connect("ucdencsesql05.ucdenver.pvt", "student01","Sbw8kzTpGvfD", "student01db");
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
else{ echo "Connected";}
$sql = "SELECT `Name`, `Price`, `Preparation`, `Units of measure (oz)` FROM `INGREDIENT`";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["Name"]. "</td><td>" . $row["Price"] . "</td><td>"
. $row["Preparation"]. "</td><td>" . $row["Units of measure (oz)"]. "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>

</table>

<br>
<br>
<br>
<br>
<br>



</body>

</html>