<?php 
 ?>

<!DOCTYPE hmtl>
<html>

<head>
	<title> Tomas Tacos - CesarRamirez </title>
	<link rel="stylesheet" type="text/css" href="homeStyle.php" />
</head>

<body>
extra &nbsp;&nbsp; space
	<h1>Tomas Tacos </h1>
	<ul class="nav">
		<li><a href="index.php">| TACOS |<a/>
		</li>
		<li><a href="sales.php">| SALES |<a/>
		</li>
		<li><a href="ingredients.php">| INGREDIENTS |<a/>
		</li>
		<li><a href="inventory.php">| INVENTORY |<a/>
		</li>
	</ul> 


  
<p> TACOS </p>
<br>

<hr>
<p> Adobada </p>
<br>



<table align = "center">
<tr>
<th>Price</th>
<th>Sold This Month</th>
<th>Sold Last Month</th>

</tr>
<?php 
$conn = mysqli_connect("ucdencsesql05.ucdenver.pvt", "student01","Sbw8kzTpGvfD", "student01db");
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
//else{ echo "Connected";}


$query = "SELECT COUNT(*) as 'total' FROM `SALES` WHERE `NAME` =  'Adobada' AND `DATE`  >  '2019-11-30 00:00:00' AND `DATE` <  '2020-01-01 00:00:00'";
$res = mysqli_query($conn, $query);
$data  = mysqli_fetch_array($res);

// output data of each row

$query2 = "SELECT COUNT(*) as 'total2' FROM `SALES` WHERE `NAME` =  'Adobada' AND `DATE`  >  '2019-11-01 00:00:00' AND `DATE` <  '2019-12-01 00:00:00'";
$res2 = mysqli_query($conn, $query2);
$data2  = mysqli_fetch_array($res2);

$sql = "SELECT  `Price` FROM `TACOS` WHERE  `Taco Name` =  'Adobada'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["Price"]."</td><td>". $data['total']."</td><td>" . $data2['total2']. "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>



</table>

<br>
<br>


<table align = "center">
<tr>
<th>Name</th>
<th>Quanitity(oz)</th>
<th>Quanitity(Count)</th>
</tr>
<?php 
$conn = mysqli_connect("ucdencsesql05.ucdenver.pvt", "student01","Sbw8kzTpGvfD", "student01db");
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
//else{ echo "Connected";}
$sql = "SELECT  `Ingredient_Name`, `Quantity`, `Quantity(COUNT)`  FROM  `Taco_Ingredient` WHERE  `Taco_Name` =  'Adobada'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["Ingredient_Name"]."</td><td>" .$row["Quantity"]."</td><td>" . $row["Quantity(COUNT)"] . "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>

</table>

<br>
<br>




<hr>
<p> Arabes </p>
<br>



<table align = "center">
<tr>
<th>Price</th>
<th>Sold This Month</th>
<th>Sold Last Month</th>

</tr>
<?php 
$conn = mysqli_connect("ucdencsesql05.ucdenver.pvt", "student01","Sbw8kzTpGvfD", "student01db");
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
//else{ echo "Connected";}


$query = "SELECT COUNT(*) as 'total' FROM `SALES` WHERE `NAME` =  'Arabes' AND `DATE`  >  '2019-11-30 00:00:00' AND `DATE` <  '2020-01-01 00:00:00'";
$res = mysqli_query($conn, $query);
$data  = mysqli_fetch_array($res);

// output data of each row

$query2 = "SELECT COUNT(*) as 'total2' FROM `SALES` WHERE `NAME` =  'Arabes' AND `DATE`  >  '2019-11-01 00:00:00' AND `DATE` <  '2019-12-01 00:00:00'";
$res2 = mysqli_query($conn, $query2);
$data2  = mysqli_fetch_array($res2);

$sql = "SELECT  `Price` FROM `TACOS` WHERE  `Taco Name` =  'Arabes'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["Price"]."</td><td>". $data['total']."</td><td>" . $data2['total2']. "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>



</table>





<br>
<br>

<table align = "center">
<tr>
<th>Name</th>
<th>Quanitity(oz)</th>
<th>Quanitity(Count)</th>
</tr>
<?php 
$conn = mysqli_connect("ucdencsesql05.ucdenver.pvt", "student01","Sbw8kzTpGvfD", "student01db");
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
//else{ echo "Connected";}
$sql = "SELECT  `Ingredient_Name`, `Quantity`, `Quantity(COUNT)`  FROM  `Taco_Ingredient` WHERE  `Taco_Name` =  'Arabes'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["Ingredient_Name"]."</td><td>" .$row["Quantity"]."</td><td>" . $row["Quantity(COUNT)"] . "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>

</table>

<br>
<br>


<hr>
<p> Asada </p>
<br>

<table align = "center">
<tr>
<th>Price</th>
<th>Sold This Month</th>
<th>Sold Last Month</th>

</tr>
<?php 
$conn = mysqli_connect("ucdencsesql05.ucdenver.pvt", "student01","Sbw8kzTpGvfD", "student01db");
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
//else{ echo "Connected";}


$query = "SELECT COUNT(*) as 'total' FROM `SALES` WHERE `NAME` =  'Asada' AND `DATE`  >  '2019-11-30 00:00:00' AND `DATE` <  '2020-01-01 00:00:00'";
$res = mysqli_query($conn, $query);
$data  = mysqli_fetch_array($res);

// output data of each row

$query2 = "SELECT COUNT(*) as 'total2' FROM `SALES` WHERE `NAME` =  'Asada' AND `DATE`  >  '2019-11-01 00:00:00' AND `DATE` <  '2019-12-01 00:00:00'";
$res2 = mysqli_query($conn, $query2);
$data2  = mysqli_fetch_array($res2);

$sql = "SELECT  `Price` FROM `TACOS` WHERE  `Taco Name` =  'Asada'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["Price"]."</td><td>". $data['total']."</td><td>" . $data2['total2']. "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>



</table>





<br>
<br>

<table align = "center">
<tr>
<th>Name</th>
<th>Quanitity(oz)</th>
<th>Quanitity(Count)</th>
</tr>
<?php 
$conn = mysqli_connect("ucdencsesql05.ucdenver.pvt", "student01","Sbw8kzTpGvfD", "student01db");
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
//else{ echo "Connected";}
$sql = "SELECT  `Ingredient_Name`, `Quantity`, `Quantity(COUNT)`  FROM  `Taco_Ingredient` WHERE  `Taco_Name` =  'Asada'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["Ingredient_Name"]."</td><td>" .$row["Quantity"]."</td><td>" . $row["Quantity(COUNT)"] . "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>

</table>

<br>
<br>

<hr>
<p> Barbacoa </p>
<br>

<table align = "center">
<tr>
<th>Price</th>
<th>Sold This Month</th>
<th>Sold Last Month</th>

</tr>
<?php 
$conn = mysqli_connect("ucdencsesql05.ucdenver.pvt", "student01","Sbw8kzTpGvfD", "student01db");
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
//else{ echo "Connected";}


$query = "SELECT COUNT(*) as 'total' FROM `SALES` WHERE `NAME` =  'Barbacoa' AND `DATE`  >  '2019-11-30 00:00:00' AND `DATE` <  '2020-01-01 00:00:00'";
$res = mysqli_query($conn, $query);
$data  = mysqli_fetch_array($res);

// output data of each row

$query2 = "SELECT COUNT(*) as 'total2' FROM `SALES` WHERE `NAME` =  'Barbacoa' AND `DATE`  >  '2019-11-01 00:00:00' AND `DATE` <  '2019-12-01 00:00:00'";
$res2 = mysqli_query($conn, $query2);
$data2  = mysqli_fetch_array($res2);

$sql = "SELECT  `Price` FROM `TACOS` WHERE  `Taco Name` =  'Barbacoa'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["Price"]."</td><td>". $data['total']."</td><td>" . $data2['total2']. "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>



</table>





<br>
<br>

<table align = "center">
<tr>
<th>Name</th>
<th>Quanitity(oz)</th>
<th>Quanitity(Count)</th>
</tr>
<?php 
$conn = mysqli_connect("ucdencsesql05.ucdenver.pvt", "student01","Sbw8kzTpGvfD", "student01db");
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
//else{ echo "Connected";}
$sql = "SELECT  `Ingredient_Name`, `Quantity`, `Quantity(COUNT)`  FROM  `Taco_Ingredient` WHERE  `Taco_Name` =  'Barbacoa'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["Ingredient_Name"]."</td><td>" .$row["Quantity"]."</td><td>" . $row["Quantity(COUNT)"] . "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>

</table>

<br>
<br>

<hr>
<p> Beef </p>
<br>

<table align = "center">
<tr>
<th>Price</th>
<th>Sold This Month</th>
<th>Sold Last Month</th>

</tr>
<?php 
$conn = mysqli_connect("ucdencsesql05.ucdenver.pvt", "student01","Sbw8kzTpGvfD", "student01db");
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
//else{ echo "Connected";}


$query = "SELECT COUNT(*) as 'total' FROM `SALES` WHERE `NAME` =  'Beef' AND `DATE`  >  '2019-11-30 00:00:00' AND `DATE` <  '2020-01-01 00:00:00'";
$res = mysqli_query($conn, $query);
$data  = mysqli_fetch_array($res);

// output data of each row

$query2 = "SELECT COUNT(*) as 'total2' FROM `SALES` WHERE `NAME` =  'Beef' AND `DATE`  >  '2019-11-01 00:00:00' AND `DATE` <  '2019-12-01 00:00:00'";
$res2 = mysqli_query($conn, $query2);
$data2  = mysqli_fetch_array($res2);

$sql = "SELECT  `Price` FROM `TACOS` WHERE  `Taco Name` =  'Beef'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["Price"]."</td><td>". $data['total']."</td><td>" . $data2['total2']. "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>



</table>





<br>
<br>

<table align = "center">
<tr>
<th>Name</th>
<th>Quanitity(oz)</th>
<th>Quanitity(Count)</th>
</tr>
<?php 
$conn = mysqli_connect("ucdencsesql05.ucdenver.pvt", "student01","Sbw8kzTpGvfD", "student01db");
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
//else{ echo "Connected";}
$sql = "SELECT  `Ingredient_Name`, `Quantity`, `Quantity(COUNT)`  FROM  `Taco_Ingredient` WHERE  `Taco_Name` =  'Beef'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["Ingredient_Name"]."</td><td>" .$row["Quantity"]."</td><td>" . $row["Quantity(COUNT)"] . "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>

</table>

<br>
<br>



<hr>
<p> Buche </p>
<br>

<table align = "center">
<tr>
<th>Price</th>
<th>Sold This Month</th>
<th>Sold Last Month</th>

</tr>
<?php 
$conn = mysqli_connect("ucdencsesql05.ucdenver.pvt", "student01","Sbw8kzTpGvfD", "student01db");
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
//else{ echo "Connected";}


$query = "SELECT COUNT(*) as 'total' FROM `SALES` WHERE `NAME` =  'Buche' AND `DATE`  >  '2019-11-30 00:00:00' AND `DATE` <  '2020-01-01 00:00:00'";
$res = mysqli_query($conn, $query);
$data  = mysqli_fetch_array($res);

// output data of each row

$query2 = "SELECT COUNT(*) as 'total2' FROM `SALES` WHERE `NAME` =  'Buche' AND `DATE`  >  '2019-11-01 00:00:00' AND `DATE` <  '2019-12-01 00:00:00'";
$res2 = mysqli_query($conn, $query2);
$data2  = mysqli_fetch_array($res2);

$sql = "SELECT  `Price` FROM `TACOS` WHERE  `Taco Name` =  'Buche'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["Price"]."</td><td>". $data['total']."</td><td>" . $data2['total2']. "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>



</table>





<br>
<br>

<table align = "center">
<tr>
<th>Name</th>
<th>Quanitity(oz)</th>
<th>Quanitity(Count)</th>
</tr>
<?php 
$conn = mysqli_connect("ucdencsesql05.ucdenver.pvt", "student01","Sbw8kzTpGvfD", "student01db");
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
//else{ echo "Connected";}
$sql = "SELECT  `Ingredient_Name`, `Quantity`, `Quantity(COUNT)`  FROM  `Taco_Ingredient` WHERE  `Taco_Name` =  'Buche'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["Ingredient_Name"]."</td><td>" .$row["Quantity"]."</td><td>" . $row["Quantity(COUNT)"] . "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>

</table>

<br>
<br>




<hr>
<p> Carnitas </p>
<br>

<table align = "center">
<tr>
<th>Price</th>
<th>Sold This Month</th>
<th>Sold Last Month</th>

</tr>
<?php 
$conn = mysqli_connect("ucdencsesql05.ucdenver.pvt", "student01","Sbw8kzTpGvfD", "student01db");
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
//else{ echo "Connected";}


$query = "SELECT COUNT(*) as 'total' FROM `SALES` WHERE `NAME` =  'Carnitas' AND `DATE`  >  '2019-11-30 00:00:00' AND `DATE` <  '2020-01-01 00:00:00'";
$res = mysqli_query($conn, $query);
$data  = mysqli_fetch_array($res);

// output data of each row

$query2 = "SELECT COUNT(*) as 'total2' FROM `SALES` WHERE `NAME` =  'Carnitas' AND `DATE`  >  '2019-11-01 00:00:00' AND `DATE` <  '2019-12-01 00:00:00'";
$res2 = mysqli_query($conn, $query2);
$data2  = mysqli_fetch_array($res2);

$sql = "SELECT  `Price` FROM `TACOS` WHERE  `Taco Name` =  'Carnitas'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["Price"]."</td><td>". $data['total']."</td><td>" . $data2['total2']. "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>



</table>





<br>
<br>

<table align = "center">
<tr>
<th>Name</th>
<th>Quanitity(oz)</th>
<th>Quanitity(Count)</th>
</tr>
<?php 
$conn = mysqli_connect("ucdencsesql05.ucdenver.pvt", "student01","Sbw8kzTpGvfD", "student01db");
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
//else{ echo "Connected";}
$sql = "SELECT  `Ingredient_Name`, `Quantity`, `Quantity(COUNT)`  FROM  `Taco_Ingredient` WHERE  `Taco_Name` =  'Carnitas'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["Ingredient_Name"]."</td><td>" .$row["Quantity"]."</td><td>" . $row["Quantity(COUNT)"] . "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>

</table>

<br>
<br>


<hr>
<p> Chicken </p>
<br>

<table align = "center">
<tr>
<th>Price</th>
<th>Sold This Month</th>
<th>Sold Last Month</th>

</tr>
<?php 
$conn = mysqli_connect("ucdencsesql05.ucdenver.pvt", "student01","Sbw8kzTpGvfD", "student01db");
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
//else{ echo "Connected";}


$query = "SELECT COUNT(*) as 'total' FROM `SALES` WHERE `NAME` =  'Chicken' AND `DATE`  >  '2019-11-30 00:00:00' AND `DATE` <  '2020-01-01 00:00:00'";
$res = mysqli_query($conn, $query);
$data  = mysqli_fetch_array($res);

// output data of each row

$query2 = "SELECT COUNT(*) as 'total2' FROM `SALES` WHERE `NAME` =  'Chicken' AND `DATE`  >  '2019-11-01 00:00:00' AND `DATE` <  '2019-12-01 00:00:00'";
$res2 = mysqli_query($conn, $query2);
$data2  = mysqli_fetch_array($res2);

$sql = "SELECT  `Price` FROM `TACOS` WHERE  `Taco Name` =  'Chicken'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["Price"]."</td><td>". $data['total']."</td><td>" . $data2['total2']. "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>



</table>





<br>
<br>

<table align = "center">
<tr>
<th>Name</th>
<th>Quanitity(oz)</th>
<th>Quanitity(Count)</th>
</tr>
<?php 
$conn = mysqli_connect("ucdencsesql05.ucdenver.pvt", "student01","Sbw8kzTpGvfD", "student01db");
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
//else{ echo "Connected";}
$sql = "SELECT  `Ingredient_Name`, `Quantity`, `Quantity(COUNT)`  FROM  `Taco_Ingredient` WHERE  `Taco_Name` =  'Chicken'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["Ingredient_Name"]."</td><td>" .$row["Quantity"]."</td><td>" . $row["Quantity(COUNT)"] . "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>

</table>

<br>
<br>


<hr>
<p> Lengua </p>
<br>

<table align = "center">
<tr>
<th>Price</th>
<th>Sold This Month</th>
<th>Sold Last Month</th>

</tr>
<?php 
$conn = mysqli_connect("ucdencsesql05.ucdenver.pvt", "student01","Sbw8kzTpGvfD", "student01db");
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
//else{ echo "Connected";}


$query = "SELECT COUNT(*) as 'total' FROM `SALES` WHERE `NAME` =  'Lengua' AND `DATE`  >  '2019-11-30 00:00:00' AND `DATE` <  '2020-01-01 00:00:00'";
$res = mysqli_query($conn, $query);
$data  = mysqli_fetch_array($res);

// output data of each row

$query2 = "SELECT COUNT(*) as 'total2' FROM `SALES` WHERE `NAME` =  'Lengua' AND `DATE`  >  '2019-11-01 00:00:00' AND `DATE` <  '2019-12-01 00:00:00'";
$res2 = mysqli_query($conn, $query2);
$data2  = mysqli_fetch_array($res2);

$sql = "SELECT  `Price` FROM `TACOS` WHERE  `Taco Name` =  'Lengua'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["Price"]."</td><td>". $data['total']."</td><td>" . $data2['total2']. "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>



</table>





<br>
<br>

<table align = "center">
<tr>
<th>Name</th>
<th>Quanitity(oz)</th>
<th>Quanitity(Count)</th>
</tr>
<?php 
$conn = mysqli_connect("ucdencsesql05.ucdenver.pvt", "student01","Sbw8kzTpGvfD", "student01db");
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
//else{ echo "Connected";}
$sql = "SELECT  `Ingredient_Name`, `Quantity`, `Quantity(COUNT)`  FROM  `Taco_Ingredient` WHERE  `Taco_Name` =  'Lengua'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["Ingredient_Name"]."</td><td>" .$row["Quantity"]."</td><td>" . $row["Quantity(COUNT)"] . "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>

</table>

<br>
<br>


<hr>
<p> Pastor </p>
<br>

<table align = "center">
<tr>
<th>Price</th>
<th>Sold This Month</th>
<th>Sold Last Month</th>

</tr>
<?php 
$conn = mysqli_connect("ucdencsesql05.ucdenver.pvt", "student01","Sbw8kzTpGvfD", "student01db");
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
//else{ echo "Connected";}


$query = "SELECT COUNT(*) as 'total' FROM `SALES` WHERE `NAME` =  'Pastor' AND `DATE`  >  '2019-11-30 00:00:00' AND `DATE` <  '2020-01-01 00:00:00'";
$res = mysqli_query($conn, $query);
$data  = mysqli_fetch_array($res);

// output data of each row

$query2 = "SELECT COUNT(*) as 'total2' FROM `SALES` WHERE `NAME` =  'Pastor' AND `DATE`  >  '2019-11-01 00:00:00' AND `DATE` <  '2019-12-01 00:00:00'";
$res2 = mysqli_query($conn, $query2);
$data2  = mysqli_fetch_array($res2);

$sql = "SELECT  `Price` FROM `TACOS` WHERE  `Taco Name` =  'Pastor'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["Price"]."</td><td>". $data['total']."</td><td>" . $data2['total2']. "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>



</table>





<br>
<br>

<table align = "center">
<tr>
<th>Name</th>
<th>Quanitity(oz)</th>
<th>Quanitity(Count)</th>
</tr>
<?php 
$conn = mysqli_connect("ucdencsesql05.ucdenver.pvt", "student01","Sbw8kzTpGvfD", "student01db");
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
//else{ echo "Connected";}
$sql = "SELECT  `Ingredient_Name`, `Quantity`, `Quantity(COUNT)`  FROM  `Taco_Ingredient` WHERE  `Taco_Name` =  'Pastor'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["Ingredient_Name"]."</td><td>" .$row["Quantity"]."</td><td>" . $row["Quantity(COUNT)"] . "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>

</table>

<br>
<br>


<hr>
<p> Potato Taco </p>
<br>

<table align = "center">
<tr>
<th>Price</th>
<th>Sold This Month</th>
<th>Sold Last Month</th>

</tr>
<?php 
$conn = mysqli_connect("ucdencsesql05.ucdenver.pvt", "student01","Sbw8kzTpGvfD", "student01db");
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
//else{ echo "Connected";}


$query = "SELECT COUNT(*) as 'total' FROM `SALES` WHERE `NAME` =  'Potato Taco' AND `DATE`  >  '2019-11-30 00:00:00' AND `DATE` <  '2020-01-01 00:00:00'";
$res = mysqli_query($conn, $query);
$data  = mysqli_fetch_array($res);

// output data of each row

$query2 = "SELECT COUNT(*) as 'total2' FROM `SALES` WHERE `NAME` =  'Potato Taco' AND `DATE`  >  '2019-11-01 00:00:00' AND `DATE` <  '2019-12-01 00:00:00'";
$res2 = mysqli_query($conn, $query2);
$data2  = mysqli_fetch_array($res2);

$sql = "SELECT  `Price` FROM `TACOS` WHERE  `Taco Name` =  'Potato Taco'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["Price"]."</td><td>". $data['total']."</td><td>" . $data2['total2']. "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>



</table>





<br>
<br>

<table align = "center">
<tr>
<th>Name</th>
<th>Quanitity(oz)</th>
<th>Quanitity(Count)</th>
</tr>
<?php 
$conn = mysqli_connect("ucdencsesql05.ucdenver.pvt", "student01","Sbw8kzTpGvfD", "student01db");
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
//else{ echo "Connected";}
$sql = "SELECT  `Ingredient_Name`, `Quantity`, `Quantity(COUNT)`  FROM  `Taco_Ingredient` WHERE  `Taco_Name` =  'Potato Taco'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["Ingredient_Name"]."</td><td>" .$row["Quantity"]."</td><td>" . $row["Quantity(COUNT)"] . "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>

</table>

<br>
<br>














</body>

</html>