h1{
  color: white;
  text-align: center;
}

body{
  background-color: black;
  margin:0;
  padding:0;
  font-family: 'Verdana';
}

.nav{
  background-color: black;
  color: white;
  list-style: none;
  text-align: center;
  padding: 20px 0 20px 0;

  border-style: double;
  border-width: 5px;
}

.nav > li {
  display: inline-block;
  padding-right: 50px;
}

.nav > li > a {

  
  text-decoration: none;
  color: white;
}


p{
  color: white;
  text-align: center;
}

.pnew{
  color: white;
  text-align: left;
}




table {
  color: white;
  text-align: center;
  border-collapse: collapse;
  width: 60%;
}

table, td, th {
  border: 1px solid white;

}


th {
  height: 40px;

}

tr:hover {background-color:silver;}

p{
  color: white;
  text-align: center;
}

title{
  color: white;
}