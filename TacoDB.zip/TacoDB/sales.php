<?php 
 ?>

<!DOCTYPE hmtl>
<html>

<head>
	<title> Tomas Tacos - CesarRamirez </title>
	<link rel="stylesheet" type="text/css" href="indexStyle.php" />
</head>

<body>
extra &nbsp;&nbsp; space
	<h1>Tomas Tacos </h1>
	<ul class="nav">
		<li><a href="index.php">| TACOS |<a/>
		</li>
		<li><a href="sales.php">| SALES |<a/>
		</li>
		<li><a href="ingredients.php">| INGREDIENTS |<a/>
		</li>
		<li><a href="inventory.php">| INVENTORY |<a/>
		</li>
	</ul> 


  
<p> SALES</p>
<br>

<table align = "center">
<tr>
<th>Total Transactions(Today)</th>
<th>Total Income(Today)</th>
</tr>



<?php 
$conn = mysqli_connect("ucdencsesql05.ucdenver.pvt", "student01","Sbw8kzTpGvfD", "student01db");
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
else{ echo "Connected";}

$query = "SELECT COUNT(*) as 'total' FROM `SALES` WHERE `DATE` = CURDATE()";
$res = mysqli_query($conn, $query);
$data  = mysqli_fetch_array($res);

// output data of each row


$query2 = "SELECT SUM( `TOTAL PRICE` ) as 'sumNEW' FROM `SALES` WHERE `DATE` = CURDATE()";
$res2 = mysqli_query($conn, $query2);
$data2  = mysqli_fetch_array($res2);

echo "<tr><td>" . $data['total']."</td><td>" . $data2['sumNEW']."</td></tr>";
echo "</table>";

$conn->close();
?>




</table>

<table align = "center">
<tr>
<th>Total Transactions(Current Month)</th>
<th>Total Income(Current Month)</th>
</tr>



<?php 
$conn = mysqli_connect("ucdencsesql05.ucdenver.pvt", "student01","Sbw8kzTpGvfD", "student01db");
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
else{ echo "Connected";}

$query = "SELECT COUNT(*) as 'total' FROM `SALES` WHERE `DATE` <= '2019-12-31 00:00:00' and `DATE` >= '2019-12-01 00:00:00'";
$res = mysqli_query($conn, $query);
$data  = mysqli_fetch_array($res);

// output data of each row


$query2 = "SELECT SUM( `TOTAL PRICE` ) as 'sumNEW' FROM `SALES` WHERE `DATE` <= '2019-12-31 00:00:00' and `DATE` >= '2019-12-01 00:00:00'";
$res2 = mysqli_query($conn, $query2);
$data2  = mysqli_fetch_array($res2);

echo "<tr><td>" . $data['total']."</td><td>" . $data2['sumNEW']."</td></tr>";
echo "</table>";

$conn->close();
?>




</table>


<table align = "center">
<tr>
<th>Total Transactions(Last Month)</th>
<th>Total Income(Last Month)</th>
</tr>



<?php 
$conn = mysqli_connect("ucdencsesql05.ucdenver.pvt", "student01","Sbw8kzTpGvfD", "student01db");
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
else{ echo "Connected";}

$query = "SELECT COUNT(*) as 'total' FROM `SALES` WHERE `DATE` <= '2019-11-30 00:00:00' and `DATE` >= '2019-11-01 00:00:00'";
$res = mysqli_query($conn, $query);
$data  = mysqli_fetch_array($res);

// output data of each row


$query2 = "SELECT SUM( `TOTAL PRICE` ) as 'sumNEW' FROM `SALES` WHERE `DATE` <= '2019-11-30 00:00:00' and `DATE` >= '2019-11-01 00:00:00'";
$res2 = mysqli_query($conn, $query2);
$data2  = mysqli_fetch_array($res2);

echo "<tr><td>" . $data['total']."</td><td>" . $data2['sumNEW']."</td></tr>";
echo "</table>";

$conn->close();
?>




</table>



<table align = "center">
<tr>
<th>Total Transactions(Last 90 Days)</th>
<th>Total Income(Last 90 Days)</th>
</tr>



<?php 
$conn = mysqli_connect("ucdencsesql05.ucdenver.pvt", "student01","Sbw8kzTpGvfD", "student01db");
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
else{ echo "Connected";}

$query = "SELECT COUNT(*) as 'total' FROM `SALES` WHERE `DATE` >= CURDATE()-INTERVAL 90 DAY and `DATE` <= CURDATE()";
$res = mysqli_query($conn, $query);
$data  = mysqli_fetch_array($res);

// output data of each row


$query2 = "SELECT SUM( `TOTAL PRICE` ) as 'sumNEW' FROM `SALES` WHERE `DATE` >= CURDATE()-INTERVAL 90 DAY and `DATE` <= CURDATE()";
$res2 = mysqli_query($conn, $query2);
$data2  = mysqli_fetch_array($res2);

echo "<tr><td>" . $data['total']."</td><td>" . $data2['sumNEW']."</td></tr>";
echo "</table>";

$conn->close();
?>




</table>






<br>
<p> FULL SALES RECORD</p>

<table align = "center" >
<tr>
<th>Taco Name</th>
<th>Quantity</th>
<th>Price</th>
<th>Date</th>
</tr>

<?php 
$conn = mysqli_connect("ucdencsesql05.ucdenver.pvt", "student01","Sbw8kzTpGvfD", "student01db");
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
else{ echo "Connected";}

$sql = "SELECT * FROM `SALES` ORDER BY `SALES`.`DATE` ASC LIMIT 0, 1000 ";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["NAME"]. "</td><td>" . $row["QUANTITY"] . "</td><td>"
. $row["TOTAL PRICE"]."</td><td>". $row["DATE"] . "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>

</table>










</body>

</html>