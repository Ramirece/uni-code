#include <iostream>
#include <string>
#include <unistd.h>
#include <vector>
#include <sstream>
#include <sys/wait.h>
#include <errno.h>
#include <fstream>

using namespace std;
bool exitShell = false;
bool hasRedirect = false;
int beforeRedirect = 0;


//Runs commands that have no arguments
void executeCommand_NO_ARG(string x)
{

  char* args[2];
  
  args[0] = (char*)x.c_str();
  args[1] = NULL;

  pid_t pid = fork();

  if(pid == 0)
  {
      //child
      //cout << "child: " << pid << endl;
      if (execvp(args[0], args) == -1)
      {
        cout << "Error: Invalid Command " << endl;
        exit(EXIT_FAILURE);
      }
  }

  if (pid > 0)
    {
        if (wait(0) == -1){
          perror("wait");
        }
        

        //cout<< "parent: " << pid <<  endl;
        //cout << endl;
    }
};


//Runs commands that have arguments
void executeCommand_WITH_ARG(vector<string> z)
{
//START FORK
//START EXEC

  

  char* args[z.size()-1];
  cout << endl;

  for(int j=0; j<z.size()-1; j++ ){
    args[j] = (char*)z[j].c_str();
  }

  args[z.size()-1] = NULL;



  //args[0] = (char*)z.c_str();
  //args[1] = (char*)y.c_str();
  //args[2] = NULL;

  
  pid_t pid = fork();

  if(pid == 0)
  {
      //child
      //cout << "child: " << pid << endl;
      if (execvp(args[0], args) == -1)
      {
        cout << "Error: Invalid Command " << endl;
        exit(EXIT_FAILURE);
      }
  }

  if (pid > 0)
    {
        if (wait(0) == -1){
          perror("wait");
        }
        //cout<< "parent: " << pid <<  endl;
        //cout << endl;
    }
  
};

//prints the prompt used by the shell and also takes the users input
string promptCommand()
{
  string shellCommand;

  cout << "$: ";
  getline(cin, shellCommand);

  return shellCommand;
};

//The shell runs and functions from here
void myShell()
{

  
  
  while(exitShell == false){
    int argumentCounter = 0;
    bool hasArguments = false;
    string fileDest = "";
    string contentBuf = "";

    string myShellCommand;
    vector<string> shellCommandParse;
    vector<string> RedirectBuf;
    string exePATH;
    
    myShellCommand = promptCommand();

    //If the user simply presses enter, display prompt again
    if(myShellCommand == "")
		{
			continue;
		}

    //Use to split the string by whitespace
    istringstream iss;
    iss.str (myShellCommand);
  
    // Traverse through all words 
    do
    { 
        string val; 
        iss >> val; 
        shellCommandParse.push_back(val);
    } 
    while (iss); 

    //Used to see exactly how many arguments were given to the command line
    for (int i = 0; i < shellCommandParse.size()-1; i++)
    {
      argumentCounter++;
    }

    //command comes with an argument
    if (argumentCounter > 1)
    {
      hasArguments = true;
    }
    //does not come with argument
    else
    {
      hasArguments = false;
    }

    //If the user types "exit" or "EXIT", stop program
    if ((shellCommandParse[0] == "exit") || (shellCommandParse[0] == "EXIT") ){
      cout << "Exiting Shell..." << endl;
      cout << endl;
      exit(0);
    }


  



    for (int i =0; i < shellCommandParse.size()-1; i++ )
    {
        if (shellCommandParse[i] ==">")
        {
        hasRedirect = true;
        beforeRedirect = i;
        fileDest = shellCommandParse[i+1];
          for (int j =0; j < beforeRedirect; j++){
            contentBuf = shellCommandParse[j];
            RedirectBuf.push_back(contentBuf);
            cout << "Vector Contents:" <<RedirectBuf[j];
          }
        cout << endl;
        }
    }

    if (hasRedirect == true){
      
      cout << "Before Redirect: " << beforeRedirect << endl;
      cout << "File to be created: " << fileDest << endl;

      ofstream file;
      file.open (fileDest);

      for (int i =0; i < shellCommandParse.size()-1; i++ ){
        file << shellCommandParse[i] << " ";
    }
      
      file.close();

      continue;
    }

















    //CD COMMAND(START) 
    if (shellCommandParse[0] == "cd")
    {


      if (shellCommandParse[1] == "")
    {
      chdir(getenv("HOME"));
      cout << endl;
      continue;
    }
      

      //printf("%s\n", getcwd(s, 100)); 
      //Used to later hold our converted .c strings
      char* argsCD[2];

    //If the user simply enters cd with no arguments
    

    string path;
    path = shellCommandParse[1];

    //Convert to c string
    argsCD[0] = (char*)path.c_str();

    //Change directory to user defined space
    int dirT = chdir(argsCD[0]); 

    if (dirT == -1){
        cout <<"ERROR: No such file or directory" << endl;
    }
    

      cout << endl;
      continue;
    }
    
    //If the command comes with arguments, execute the following function
    /*if(hasArguments == false){
    executeCommand_NO_ARG(shellCommandParse[0]);
    }
    */

    //If the command comes with no arguments, execute the following function
    if(hasArguments == true || hasArguments == false ){
    executeCommand_WITH_ARG(shellCommandParse);
    }

    cout << endl;

  }
  return;
};

int main() {
  cout << endl << "----------Shell Desiged By Cesar Ramirez----------" << endl;
  myShell();
};