#!/usr/bin/env python
# coding: utf-8

# In[1]:


import heapq
from timeit import default_timer as timer
import plotly.graph_objects as go

ML = []
SixInteger = []
Y = "0123456789"
RC = 0
hash_key = 0
number_collision = 0
CList = []
KEYList = []

hashMap = [[] for bucket in range(15000)]


#read in files for the 1000000 value test
theFile = open("C:/Users/cesar/Desktop/test/rand1000000.txt", 'r')
for val in theFile.read().split():
    ML.append(str(val))
theFile.close()
   
def timeEfficiency(x):  
    start = timer()
    x()
    end = timer()   
    print("Time taken to execute:", end - start)


def lcs(X, Y, m, n):
    global RC
    RC = RC + 1
    
    if RC >= 10000:
        #print ("LIMIT HIT AT:",  RC)
        RC = 0
        #print ("RESET:",  RC)
        
    if m == 0 or n == 0: 
       return 0; 
    elif X[m-1] == Y[n-1]: 
       return 1 + lcs(X, Y, m-1, n-1); 
    else: 
       return max(lcs(X, Y, m, n-1), lcs(X, Y, m-1, n));
    

def lcsnew(X, Y): 

    m = len(X) 
    n = len(Y) 
    L = [[None]*(n + 1) for i in range(m + 1)] 

    for i in range(m + 1): 
        for j in range(n + 1): 
            if i == 0 or j == 0 : 
                L[i][j] = 0
            elif X[i-1] == Y[j-1]: 
                L[i][j] = L[i-1][j-1]+1
            else: 
                L[i][j] = max(L[i-1][j], L[i][j-1]) 
                
    return L[m][n] 



for i in range(len(ML)):

    if (len(ML[i]) == 6 ):
        SixInteger.append(ML[i])

def recursiveRUN():
    x = 0
    #print("(LCS NUMBER / RECURSIVE CALLS):")
    
    for j in range(len(SixInteger)):
        global RC
        RC=0
        tupleResult = (0,0)
        X = str(SixInteger[j])
        tupleResult = (lcs(X, Y, len(X), len(Y)), RC)
        
        global hash_key
        hash_key = tupleResult[1]% len(hashMap)

        if hashMap[hash_key]:
            
            global number_collision
            number_collision = number_collision+1
            hashMap[hash_key][1] = hashMap[hash_key][1]+1
            hashMap[hash_key].append(tupleResult)
            
        else:
            hashMap[hash_key].append(tupleResult)
            hashMap[hash_key].append(x)
            hashMap[hash_key].append(hash_key)
        
        
        
def dpRUN():
    for p in range(len(SixInteger)):
       
        X = str(SixInteger[p])

        lcsnew(X, Y)
        
print("")
#print("LCS recursive") 
timeEfficiency(recursiveRUN)

list_Range =  len(hashMap)

for x in range (list_Range):
    if hashMap[x]:
        
        CList.append(hashMap[x][1])
        KEYList.append(hashMap[x][2])
    else:
        pass

fig = go.Figure([go.Bar(x=KEYList, y=CList, marker_color='black' )])

fig.update_layout(title_text='LCS Hash Uniformity', yaxis=dict(
        title='Collision Size Per Bucket',
        titlefont_size=16,
        tickfont_size=14,), xaxis=dict(
        title='Hash Keys',
        titlefont_size=16,
        tickfont_size=14,), plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)')

fig.write_html('LCS Hash Uniformity.html', auto_open=True)


# In[ ]:




