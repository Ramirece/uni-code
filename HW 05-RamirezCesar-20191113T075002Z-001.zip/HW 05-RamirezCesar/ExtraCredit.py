#!/usr/bin/env python
# coding: utf-8

# In[23]:


#!/usr/bin/env python
# coding: utf-8

# In[39]:


from __future__ import print_function
import heapq
from timeit import default_timer as timer


ML = []
MLSEARCH = []
NodeCounter = 0


ones = {
    0: '', 1: 'one', 2: 'two', 3: 'three', 4: 'four', 5: 'five', 6: 'six',
    7: 'seven', 8: 'eight', 9: 'nine', 10: 'ten', 11: 'eleven', 12: 'twelve',
    13: 'thirteen', 14: 'fourteen', 15: 'fifteen', 16: 'sixteen',
    17: 'seventeen', 18: 'eighteen', 19: 'nineteen'}
tens = {
    2: 'twenty', 3: 'thirty', 4: 'forty', 5: 'fifty', 6: 'sixty',
    7: 'seventy', 8: 'eighty', 9: 'ninety'}
illions = {
    1: 'thousand', 2: 'million', 3: 'billion', 4: 'trillion', 5: 'quadrillion',
    6: 'quintillion', 7: 'sextillion', 8: 'septillion', 9: 'octillion',
    10: 'nonillion', 11: 'decillion'}

class Node(object):
    """Tree node: left and right child + data which can be any object
    """
    def __init__(self, data):
        """Node constructor
        @param data node data object
        """
        self.left = None
        self.right = None
        self.data = data

    def insert(self, data):
        """Insert new node with data
        @param data node data object to insert
        """
        if self.data:
            if data < self.data:
                if self.left is None:
                    self.left = Node(data)
                else:
                    self.left.insert(data)
            elif data > self.data:
                if self.right is None:
                    self.right = Node(data)
                else:
                    self.right.insert(data)
        else:
            self.data = data

    def lookup(self, data, parent=None):
        """Lookup node containing data
        @param data node data object to look up
        @param parent node's parent
        @returns node and node's parent if found or None, None
        """
        if data < self.data:
            if self.left is None:
                return None, None
            return self.left.lookup(data, self)
        elif data > self.data:
            if self.right is None:
                return None, None
            return self.right.lookup(data, self)
        else:
            return self, parent

    def delete(self, data):
        """Delete node containing data
        @param data node's content to delete
        """
        # get node containing data
        node, parent = self.lookup(data)
        if node is not None:
            children_count = node.children_count()
            if children_count == 0:
                # if node has no children, just remove it
                if parent:
                    if parent.left is node:
                        parent.left = None
                    else:
                        parent.right = None
                else:
                    self.data = None
            elif children_count == 1:
                # if node has 1 child
                # replace node by its child
                if node.left:
                    n = node.left
                else:
                    n = node.right
                if parent:
                    if parent.left is node:
                        parent.left = n
                    else:
                        parent.right = n
                else:
                    self.left = n.left
                    self.right = n.right
                    self.data = n.data
            else:
                # if node has 2 children
                # find its successor
                parent = node
                successor = node.right
                while successor.left:
                    parent = successor
                    successor = successor.left
                # replace node data by its successor data
                node.data = successor.data
                # fix successor's parent node child
                if parent.left == successor:
                    parent.left = successor.right
                else:
                    parent.right = successor.right

    def compare_trees(self, node):
        """Compare 2 trees
        @param node tree to compare
        @returns True if the tree passed is identical to this tree
        """
        if node is None:
            return False
        if self.data != node.data:
            return False
        res = True
        if self.left is None:
            if node.left:
                return False
        else:
            res = self.left.compare_trees(node.left)
        if res is False:
            return False
        if self.right is None:
            if node.right:
                return False
        else:
            res = self.right.compare_trees(node.right)
        return res

    def print_tree(self):
        """Print tree content inorder
        """
        if self.left:
            self.left.print_tree()
        print(self.data, end=" ")
        if self.right:
            self.right.print_tree()

    def tree_data(self):
        """Generator to get the tree nodes data
        """
        # we use a stack to traverse the tree in a non-recursive way
        stack = []
        node = self
        while stack or node:
            if node:
                stack.append(node)
                node = node.right
            else:
                # we are returning so we pop the node and we yield it
                node = stack.pop()
                yield node.data
                node = node.left

    def children_count(self):
        """Return the number of children
        @returns number of children: 0, 1, 2
        """
        cnt = 0
        if self.left:
            cnt += 1
        if self.right:
            cnt += 1
        return cnt
    
    def node_count_inner(self):
        global NodeCounter
        """Print tree content inorder
        """
        if self.left:
            self.left.node_count_inner()
        NodeCounter = NodeCounter+1
        if self.right:
            self.right.node_count_inner()
            
    def node_count(self):
        global NodeCounter
        NodeCounter = 0
        """Print tree content inorder
        """
        self.node_count_inner()
        print("Nodes In Tree:", NodeCounter)
        
    def getHeight(self):
        if self.left and self.right:
            return 1 + max(self.left.getHeight(), self.right.getHeight())
        elif self.left:
            return 1 + self.left.getHeight()
        elif self.right:
            return 1 + self.right.getHeight()
        else:
            return 1
        
                
def number_to_word(i):
    if i < 0:
        return _join('negative', _say_number_pos(-i))
    if i == 0:
        return 'zero'
    return _say_number_pos(i)


def _say_number_pos(i):
    if i < 20:
        return ones[i]
    if i < 100:
        return _join(tens[i // 10], ones[i % 10])
    if i < 1000:
        return _divide(i, 100, 'hundred')
    for illions_number, illions_name in illions.items():
        if i < 1000**(illions_number + 1):
            break
    return _divide(i, 1000**illions_number, illions_name)


def _divide(dividend, divisor, magnitude):
    return _join(
        _say_number_pos(dividend // divisor),
        magnitude,
        _say_number_pos(dividend % divisor),
    )


def _join(*args):
    return ' '.join(filter(bool, args))    
            

    
print("Creating and populating tree with file provided:")   
#read in files for the 1000000 value test
theFile = open("C:/Users/cesar/Desktop/test/rand1000000.txt", 'r')
for val in theFile.read().split():
    ML.append(int(val))
theFile.close()    
  
length = len(ML)    
    
for i in range(length): 
    #print(i)
    
    if (i == 0):
        root = Node(ML[i])
        
    root.insert(ML[i])
    
    
#read in files for the 100 value test
theFileNew = open("C:/Users/cesar/Desktop/test/rand100.txt", 'r')
for val in theFileNew.read().split():
    MLSEARCH.append(int(val))
theFileNew.close() 

length100 = len(MLSEARCH)    
    
for i in range(length100): 
    #print(i)
    if (i == 0):
        rootNEW = Node(MLSEARCH[i])
    rootNEW.insert(MLSEARCH[i])
     
#rootNEW.print_tree()
#print("")
#print("")






print("Height of Tree: ",root.getHeight())
root.node_count()
print("")
print(" Adding Node...")
root.insert(12345678987654321)
root.node_count()
print(" Deleting Node...")
root.delete(12345678987654321)
root.node_count()

print("")
print("100 nodes from rand100.txt:")
for data in rootNEW.tree_data():
    
    word = number_to_word(data)
    
    print (data, ": ", end='')
    print(word)




# In[ ]:





# In[ ]:




# In[ ]:




