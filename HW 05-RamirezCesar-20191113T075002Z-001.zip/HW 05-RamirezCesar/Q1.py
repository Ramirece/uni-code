#!/usr/bin/env python
# coding: utf-8

# In[23]:


#CESAR RAMIREZ

import heapq
from timeit import default_timer as timer
import plotly.graph_objects as go

ML = []
SixInteger = []
Y = "0123456789"

hash_key = 0
number_collision = 0


#read in files for the 1000000 value test
theFile = open("C:/Users/cesar/Desktop/test/rand1000000.txt", 'r')
for val in theFile.read().split():
    ML.append(str(val))
theFile.close()

#timer to test the insert sort function on 1000000 values    
def timeEfficiency(x):  
    start = timer()
    x()
    end = timer()   
    print("Time taken to execute:", end - start)


def lcs(X, Y, m, n):
    if m == 0 or n == 0: 
       return 0; 
    elif X[m-1] == Y[n-1]: 
       return 1 + lcs(X, Y, m-1, n-1); 
    else: 
       return max(lcs(X, Y, m, n-1), lcs(X, Y, m-1, n));


def lcsnew(X, Y): 
    m = len(X) 
    n = len(Y) 
  

    L = [[None]*(n + 1) for i in range(m + 1)] 
  
    for i in range(m + 1): 
        for j in range(n + 1): 
            if i == 0 or j == 0 : 
                L[i][j] = 0
            elif X[i-1] == Y[j-1]: 
                L[i][j] = L[i-1][j-1]+1
            else: 
                L[i][j] = max(L[i-1][j], L[i][j-1]) 
    return L[m][n] 

for i in range(len(ML)):
    if (len(ML[i]) == 6 ):
        SixInteger.append(ML[i])
    
    
def recursiveRUN():
    x = 0
    #print("(LCS NUMBER / RECURSIVE CALLS):")
    for j in range(len(SixInteger)):
        X = str(SixInteger[j])
        (lcs(X, Y, len(X), len(Y)),)

        
def dpRUN():
    for p in range(len(SixInteger)):
        #print(p)
        X = str(SixInteger[p])
        #print("X", X)
        #print("Y", Y)
        lcsnew(X, Y)
        

#print(len(SixInteger))     

print("")
print("LCS recursive") 
timeEfficiency(recursiveRUN)
print("LCS DP") 
timeEfficiency(dpRUN)


# In[ ]:




